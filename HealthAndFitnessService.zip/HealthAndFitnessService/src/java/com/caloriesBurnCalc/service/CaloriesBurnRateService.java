/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.caloriesBurnCalc.service;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author faiza
 */
@WebService(serviceName = "CaloriesBurnRateService")
public class CaloriesBurnRateService {

    @WebMethod(operationName = "calculateCaloriesBurned")
public String calculateCaloriesBurned(
        @WebParam(name = "name") String name,
        @WebParam(name = "weight") double weight,
        @WebParam(name = "activity") String activity,
        @WebParam(name = "durationMinutes") int durationMinutes) {

    if (weight <= 0 || durationMinutes <= 0 || activity == null || activity.isEmpty()) {
        return "SOAP Fault: Invalid input. Please provide valid weight, duration, and activity.";
    }

    double met;
    switch (activity.toLowerCase()) {
        case "walking":
            met = 3.5;
            break;
        case "running":
            met = 8.3;
            break;
        case "cycling":
            met = 6.8;
            break;
        case "swimming":
            met = 7.0;
            break;
        case "weightlifting":
            met = 3.0;
            break;
        default:
            return "SOAP Fault: Unsupported activity. Supported activities are walking, running, cycling, swimming, and weightlifting.";
    }

    double durationHours = durationMinutes / 60.0;
    double caloriesBurned = met * weight * durationHours;

    return String.format("Hello %s, you burned approximately %.2f calories after %d minutes of %s.",
            name, caloriesBurned, durationMinutes, activity.toLowerCase());
}
}
