package com.BFPcalc.client;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class BFPcalcClient extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            String gender = request.getParameter("gender");
            int age = Integer.parseInt(request.getParameter("age"));
            double weight = Double.parseDouble(request.getParameter("weight")); // kg
            double height = Double.parseDouble(request.getParameter("height")); // cm
            double waist = Double.parseDouble(request.getParameter("waist"));   // cm
            double neck = Double.parseDouble(request.getParameter("neck"));     // cm
            double hip = gender.equalsIgnoreCase("female") ? 
                Double.parseDouble(request.getParameter("hip")) : 0;           // cm or 0 for male

            // Convert to inches for USC method
            double heightInches = height / 2.54;
            double waistInches = waist / 2.54;
            double neckInches = neck / 2.54;
            double hipInches = hip / 2.54;

            // Calculate BMI
            double heightM = height / 100.0;
            double bmi = weight / (heightM * heightM);

            // Calculate BFP using all three methods
            double bfpBMI = calculateBFPWithBMI(gender, age, bmi);
            double bfpUSC = calculateBFPWithUSC(gender, waistInches, neckInches, hipInches, heightInches);
            double bfpSI = calculateBFPWithSI(gender, waist, neck, hip, height);

            // Average body fat
            double avgBFP = (bfpBMI + bfpUSC + bfpSI) / 3.0;
            double fatMass = (avgBFP / 100.0) * weight;
            double leanMass = weight - fatMass;

            // Categories
            String categoryBMI = getBodyFatCategory(gender, bfpBMI);
            String categoryUSC = getBodyFatCategory(gender, bfpUSC);
            String categorySI = getBodyFatCategory(gender, bfpSI);

            // Output HTML
            out.println("<h1>Body Fat Percentage Results</h1>");
            out.println("<p>BMI Method: " + String.format("%.1f", bfpBMI) + "% (" + categoryBMI + ")</p>");
            out.println("<p>US Navy (USC): " + String.format("%.1f", bfpUSC) + "% (" + categoryUSC + ")</p>");
            out.println("<p>US Navy (SI): " + String.format("%.1f", bfpSI) + "% (" + categorySI + ")</p>");
            out.println("<p>Average Body Fat: " + String.format("%.1f", avgBFP) + "%</p>");
            out.println("<p>Body Fat Mass: " + String.format("%.1f", fatMass) + " kg</p>");
            out.println("<p>Lean Body Mass: " + String.format("%.1f", leanMass) + " kg</p>");


        } catch (Exception e) {
            out.println("<p>Error: " + e.getMessage() + "</p>");
        } finally {
            out.close();
        }
    }

    private double calculateBFPWithBMI(String gender, int age, double bmi) {
        if (gender.equalsIgnoreCase("male")) {
            return (1.20 * bmi) + (0.23 * age) - 16.2;
        } else {
            return (1.20 * bmi) + (0.23 * age) - 5.4;
        }
    }

    private double calculateBFPWithUSC(String gender, double waist, double neck, double hip, double height) {
        if (gender.equalsIgnoreCase("male")) {
            double abdomenNeck = waist - neck;
            return 86.010 * Math.log10(abdomenNeck) - 70.041 * Math.log10(height) + 36.76;
        } else {
            double waistHipNeck = waist + hip - neck;
            return 163.205 * Math.log10(waistHipNeck) - 97.684 * Math.log10(height) - 78.387;
        }
    }

    private double calculateBFPWithSI(String gender, double waist, double neck, double hip, double height) {
        if (gender.equalsIgnoreCase("male")) {
            double waistNeck = waist - neck;
            return (495 / (1.0324 - 0.19077 * Math.log10(waistNeck) + 0.15456 * Math.log10(height))) - 450;
        } else {
            double waistHipNeck = waist + hip - neck;
            return (495 / (1.29579 - 0.35004 * Math.log10(waistHipNeck) + 0.22100 * Math.log10(height))) - 450;
        }
    }

    private String getBodyFatCategory(String gender, double bfp) {
        if (gender.equalsIgnoreCase("male")) {
            if (bfp < 5) return "Essential fat";
            if (bfp <= 13) return "Athletes";
            if (bfp <= 17) return "Fitness";
            if (bfp <= 24) return "Average";
            return "Obese";
        } else {
            if (bfp < 10) return "Essential fat";
            if (bfp <= 20) return "Athletes";
            if (bfp <= 24) return "Fitness";
            if (bfp <= 31) return "Average";
            return "Obese";
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
