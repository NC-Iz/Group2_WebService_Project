/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.BFPcalc.service;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author faiza
 */
@WebService
public class BFPCalculatorService {
    
    @WebMethod
    public String calculateBFP(String gender, int age, double weight, double height, 
                             double waist, double neck, double hip) {
        try {
            // Calculate BMI
            double heightM = height / 100;
            double bmi = weight / (heightM * heightM);
            
            // Calculate all methods
            double bfpBMI = calculateBFPWithBMI(gender, age, bmi);
            double bfpUSC = calculateBFPWithUSC(gender, waist, neck, hip, height);
            double bfpSI = calculateBFPWithSI(gender, waist, neck, hip, height);
            
            // Calculate fat and lean mass
            double avgBFP = (bfpBMI + bfpUSC + bfpSI) / 3;
            double fatMass = (avgBFP / 100) * weight;
            double leanMass = weight - fatMass;
            
            // Get categories
            String categoryBMI = getBodyFatCategory(gender, bfpBMI);
            String categoryUSC = getBodyFatCategory(gender, bfpUSC);
            String categorySI = getBodyFatCategory(gender, bfpSI);
            
            return String.format(
                "BMI Method: %.2f%% (%s)\n" +
                "US Navy (USC): %.2f%% (%s)\n" +
                "US Navy (SI): %.2f%% (%s)\n\n" +
                "Average Body Fat: %.2f%%\n" +
                "Fat Mass: %.2f kg\n" +
                "Lean Mass: %.2f kg",
                bfpBMI, categoryBMI,
                bfpUSC, categoryUSC,
                bfpSI, categorySI,
                avgBFP, fatMass, leanMass);
                
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
    
    private double calculateBFPWithBMI(String gender, int age, double bmi) {
        if (gender.equalsIgnoreCase("male")) {
            return (1.20 * bmi) + (0.23 * age) - 16.2;
        } else {
            return (1.20 * bmi) + (0.23 * age) - 5.4;
        }
    }
    
    private double calculateBFPWithUSC(String gender, double waist, double neck, double hip, double height) {
        if (gender.equalsIgnoreCase("male")) {
            double abdomenNeck = waist - neck;
            return 86.010 * Math.log10(abdomenNeck) - 70.041 * Math.log10(height) + 36.76;
        } else {
            double waistHipNeck = waist + hip - neck;
            return 163.205 * Math.log10(waistHipNeck) - 97.684 * Math.log10(height) - 78.387;
        }
    }
    
    private double calculateBFPWithSI(String gender, double waist, double neck, double hip, double height) {
        if (gender.equalsIgnoreCase("male")) {
            double waistNeck = waist - neck;
            return (495 / (1.0324 - 0.19077 * Math.log10(waistNeck) + 0.15456 * Math.log10(height))) - 450;
        } else {
            double waistHipNeck = waist + hip - neck;
            return (495 / (1.29579 - 0.35004 * Math.log10(waistHipNeck) + 0.22100 * Math.log10(height))) - 450;
        }
    }
    
    private String getBodyFatCategory(String gender, double bfp) {
        if (gender.equalsIgnoreCase("male")) {
            if (bfp < 5) return "Essential fat";
            if (bfp <= 13) return "Athletes";
            if (bfp <= 17) return "Fitness";
            if (bfp <= 24) return "Average";
            return "Obese";
        } else {
            if (bfp < 10) return "Essential fat";
            if (bfp <= 20) return "Athletes";
            if (bfp <= 24) return "Fitness";
            if (bfp <= 31) return "Average";
            return "Obese";
        }
    }
}