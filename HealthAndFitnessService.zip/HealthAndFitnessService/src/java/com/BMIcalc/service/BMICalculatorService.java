/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.BMIcalc.service;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author faiza
 */
@WebService(serviceName = "BMICalculatorService")
public class BMICalculatorService {

    @WebMethod(operationName = "calculateBMI")
    public String calculateBMI(
            @WebParam(name = "name") String name,
            @WebParam(name = "weight") double weight,   // in kg
            @WebParam(name = "heightCm") double heightCm) { // in cm

        // Input validation
        if (heightCm <= 0 || weight <= 0) {
            return "SOAP Fault: Invalid input. Height and Weight must be positive numbers.";
        }

        // Convert cm to meters
        double heightInMeters = heightCm / 100.0;

        // Calculate BMI
        double bmi = weight / (heightInMeters * heightInMeters);
        String category;

        if (bmi < 18.5) {
            category = "Underweight";
        } else if (bmi < 25) {
            category = "Normal weight";
        } else if (bmi < 30) {
            category = "Overweight";
        } else {
            category = "Obese";
        }

        return "Hello " + name + ", your BMI is " + String.format("%.2f", bmi) +
               " which is considered: " + category;
    }
}
