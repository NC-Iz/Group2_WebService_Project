package com.SNEcalc.service;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import java.util.HashMap;
import java.util.Map;

@WebService(serviceName = "SNECalculatorService")
public class SNECalculatorService {

    private static final Map<String, int[]> ageSleepMap = new HashMap<>();

    static {
        // Updated to exactly match the table with correct hours
        ageSleepMap.put("0-3 months", new int[]{14, 17});
        ageSleepMap.put("4-12 months", new int[]{12, 16});
        ageSleepMap.put("1-2 years", new int[]{11, 14});
        ageSleepMap.put("3-5 years", new int[]{10, 13});
        ageSleepMap.put("6-12 years", new int[]{9, 12});
        ageSleepMap.put("13-18 years", new int[]{8, 10});
        ageSleepMap.put("18-60 years", new int[]{7, 9});
        ageSleepMap.put("61-64 years", new int[]{7, 9});
        ageSleepMap.put("65+ years", new int[]{7, 8});
    }

    @WebMethod(operationName = "calculateSleepTimes")
    public String calculateSleepTimes(@WebParam(name = "ageRange") String ageRange,
                                    @WebParam(name = "scheduleType") String scheduleType,
                                    @WebParam(name = "timeInput") String timeInput) {

        StringBuilder result = new StringBuilder();
        result.append("<div style='font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;'>");
        result.append("<h1 style='color: #2c3e50;'>Sleep Calculator</h1>");
        result.append("<p style='color: #7f8c8d;'>It typically takes 15 minutes to fall asleep.</p>");

        // Get the correct sleep range for the age group
        int[] range = ageSleepMap.getOrDefault(ageRange, new int[]{7, 9});
        int minSleep = range[0];
        int maxSleep = range[1];

        String[] timeParts = timeInput.split(":");
        int hours = Integer.parseInt(timeParts[0]);
        int minutes = Integer.parseInt(timeParts[1]);
        int inputTotalMinutes = hours * 60 + minutes;

        if (scheduleType.equalsIgnoreCase("wakeUp")) {
            result.append("<h3 style='color: #3498db;'>If you want to wake up at ")
                  .append(formatTime24to12(timeInput))
                  .append(", try falling asleep between these times:</h3>");

            // Calculate bedtimes based on the age-specific sleep range
            int earliestBedtime = inputTotalMinutes - (maxSleep * 60) - 15;
            int latestBedtime = inputTotalMinutes - (minSleep * 60) - 15;

            result.append("<div style='background-color: #f8f9fa; padding: 15px; border-radius: 5px;'>");
            result.append("<p><strong>Earliest bedtime (for ").append(maxSleep).append(" hours sleep):</strong> ")
                  .append(formatTime(earliestBedtime)).append("</p>");
            result.append("<p><strong>Latest bedtime (for ").append(minSleep).append(" hours sleep):</strong> ")
                  .append(formatTime(latestBedtime)).append("</p>");
            result.append("</div>");

            // Calculate optimal sleep time (midpoint of range)
            int optimalSleep = (maxSleep + minSleep) / 2;
            int optimalBedtime = inputTotalMinutes - (optimalSleep * 60) - 15;
            result.append("<p style='margin-top: 20px;'><strong>Suggested optimal bedtime (")
                  .append(optimalSleep).append(" hours sleep):</strong> ")
                  .append(formatTime(optimalBedtime)).append("</p>");

        } else { // bedTime calculation
            result.append("<h3 style='color: #3498db;'>If you go to bed at ")
                  .append(formatTime24to12(timeInput))
                  .append(", try waking up between these times:</h3>");

            // Calculate wake times based on the age-specific sleep range
            int earliestWakeTime = inputTotalMinutes + (minSleep * 60) + 15;
            int latestWakeTime = inputTotalMinutes + (maxSleep * 60) + 15;

            result.append("<div style='background-color: #f8f9fa; padding: 15px; border-radius: 5px;'>");
            result.append("<p><strong>Earliest wake time (after ").append(minSleep).append(" hours sleep):</strong> ")
                  .append(formatTime(earliestWakeTime)).append("</p>");
            result.append("<p><strong>Latest wake time (after ").append(maxSleep).append(" hours sleep):</strong> ")
                  .append(formatTime(latestWakeTime)).append("</p>");
            result.append("</div>");

            // Calculate optimal wake time (midpoint of range)
            int optimalSleep = (maxSleep + minSleep) / 2;
            int optimalWakeTime = inputTotalMinutes + (optimalSleep * 60) + 15;
            result.append("<p style='margin-top: 20px;'><strong>Suggested optimal wake time (")
                  .append(optimalSleep).append(" hours sleep):</strong> ")
                  .append(formatTime(optimalWakeTime)).append("</p>");
        }

        // Show the recommended sleep range for the age group
        result.append("<div style='margin-top: 30px;'>");
        result.append("<h4>Recommended Sleep Range for ").append(ageRange).append(":</h4>");
        result.append("<p>").append(minSleep).append(" to ").append(maxSleep).append(" hours per day</p>");
        result.append("</div>");

        result.append("</div>");
        return result.toString();
    }

    private String formatTime(int totalMinutes) {
        totalMinutes = (totalMinutes + 1440) % 1440;
        int hours = totalMinutes / 60;
        int mins = totalMinutes % 60;
        String period = (hours >= 12) ? "PM" : "AM";
        hours = hours % 12;
        if (hours == 0) hours = 12;
        return String.format("%02d:%02d %s", hours, mins, period);
    }

    private String formatTime24to12(String time24) {
        String[] parts = time24.split(":");
        int hours = Integer.parseInt(parts[0]);
        int minutes = Integer.parseInt(parts[1]);
        String period = (hours >= 12) ? "PM" : "AM";
        hours = hours % 12;
        if (hours == 0) hours = 12;
        return String.format("%02d:%02d %s", hours, minutes, period);
    }
}